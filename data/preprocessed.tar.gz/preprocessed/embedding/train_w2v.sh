#!/bin/sh

gcc word2vec.c -o word2vec -lm -pthread -O2 -Wall -funroll-loops -Wno-unused-result

./word2vec -train train-w2v.txt -save-vocab vocab.txt -output 20newsVec.txt -cbow 0 -size 100 -window 5 -negative 5 -hs 0 -sample 1e-4 -threads 10 -min-count 5 -binary 0 -iter 2